﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;




public partial class Registration : System.Web.UI.Page
{

    //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["grocery"].ConnectionString);
    //SqlCommand cmd;
    //protected void page_Load(object sender, EventArgs e)
    //{
    //    con.Open();

    //}
    protected void bt_insert(object sender, EventArgs e)
    {
    //    string str = "insert into info values(" + Convert.ToInt32(tuser.Text) + ",'" + tname.Text + "'," + Convert.ToInt64(tmo.Text) + ",'" + temail.Text + "','" + tcity.Text + "','" + tadd.Text + "'," + Convert.ToInt32(tpincode.Text) + ",'" + tpass.Text + "','" + tcpass.Text + "')";
    //    cmd = new SqlCommand(str, con);
    //    int r = cmd.ExecuteNonQuery();
    //    if (r > 0)
    //    {
    //        result.Text = "data insert successfully";
    //        cleartext();
    }

    //}
    //public void cleartext()
    //{
    //    tuser.Text = "";
    //    tname.Text = "";
    //    tmo.Text = "";
    //    temail.Text = "";
    //    tcity.Text = "";
    //    tadd.Text = "";
    //    tpincode.Text = "";
    //    tpass.Text = "";
    //    tcpass.Text = "";


    //}
}
       



